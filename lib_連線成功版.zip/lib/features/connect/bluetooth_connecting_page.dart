// lib/features/connect/bluetooth_connecting_page.dart
import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart' as fbp;

import '../../services/bluetooth_service.dart' as bt;
import '../../services/nearby_presence.dart';
import '../exchange/card_exchange_page.dart'; // ★ 新增：交換頁

class BluetoothConnectingPage extends StatefulWidget {
  const BluetoothConnectingPage({super.key, this.onCancel});
  final VoidCallback? onCancel;

  @override
  State<BluetoothConnectingPage> createState() => _BluetoothConnectingPageState();
}

class _BluetoothConnectingPageState extends State<BluetoothConnectingPage> {
  fbp.BluetoothDevice? _selected; // 只保留給底部「完成」鍵（現在不太需要）

  @override
  void initState() {
    super.initState();

    // 先保險重啟廣播（iOS 偶發殘留）
    NearbyPresence.I.restart();

    () async {
      await bt.BluetoothService.I.init();
      await bt.BluetoothService.I.ensurePermissions();
      await bt.BluetoothService.I.waitUntilPoweredOn();
      bt.BluetoothService.I.startScan();

      // 如果 2 秒內都沒看到可解析的，重啟一次廣播
      Future.delayed(const Duration(seconds: 2), () {
        final any = bt.BluetoothService.I.results.value.any(
          (r) => NearbyPresence.parseAdvAll(r.advertisementData) != null,
        );
        if (!any) NearbyPresence.I.restart();
      });
    }();
  }

  @override
  void dispose() {
    bt.BluetoothService.I.stopScan();
    super.dispose();
  }

  ParsedAdv? _parsed(fbp.AdvertisementData adv) {
    return NearbyPresence.parseAdvAll(adv);
  }

  String _prettyName(fbp.ScanResult r) {
    final n = r.advertisementData.advName;
    return n.isNotEmpty ? n : r.device.remoteId.str;
  }

  Future<void> _goExchangeIfPossible(fbp.ScanResult r) async {
    final parsed = _parsed(r.advertisementData);
    if (parsed == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('無法辨識此裝置的身分')),
      );
      return;
    }

    if (parsed.userId < 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('對方尚未帶身分，請對方停留在配對頁')),
      );
      return;
    }

    // 停止掃描，避免背景干擾與耗電
    await bt.BluetoothService.I.stopScan();

    // 進交換頁（帶 userId 與 token）
    await Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => CardExchangePage(
        peerUserId: parsed.userId,
        sessionToken: parsed.token,
      ),
    ));

    // 回來後恢復掃描（讓列表可繼續刷新）
    bt.BluetoothService.I.startScan();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('連線裝置'),
        actions: [
          IconButton(
            onPressed: () {
              NearbyPresence.I.restart();
              bt.BluetoothService.I.stopScan();
              bt.BluetoothService.I.startScan();
            },
            icon: const Icon(Icons.refresh),
            tooltip: '重新整理',
          ),
        ],
      ),
      body: ValueListenableBuilder<List<fbp.ScanResult>>(
        valueListenable: bt.BluetoothService.I.results,
        builder: (context, list, _) {
          // 只留可解析（mfg 12B 或我們的 Service UUID）
          final filtered = list.where((r) {
            final p = _parsed(r.advertisementData);

            // 調試日誌（看 mfg/service 回來狀況）
            final adv = r.advertisementData;
            debugPrint(
              'ADV ${_prettyName(r)} | '
              'mfgKeys=${adv.manufacturerData.keys.toList()} | '
              'lens={${adv.manufacturerData.map((k, v) => MapEntry(k, v.length))}} | '
              'uuids=${adv.serviceUuids.map((g) => g.str).toList()} | '
              '${p == null ? 'parsed=null' : 'parsed=ok(userId=${p.userId})'}',
            );

            return p != null;
          }).toList()
            ..sort((a, b) => b.rssi.compareTo(a.rssi)); // RSSI 由強到弱

          if (filtered.isEmpty) {
            return const Center(
              child: Text('搜尋中… 請確定對方停留在配對頁且螢幕亮著'),
            );
          }

          return ListView.separated(
            itemCount: filtered.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (context, i) {
              final r = filtered[i];
              final name = _prettyName(r);
              final parsed = _parsed(r.advertisementData)!;
              final isSel = _selected?.remoteId.str == r.device.remoteId.str;

              return ListTile(
                title: Text(name),
                subtitle: Text(
                  parsed.userId >= 0
                      ? 'App 對象｜userId ${parsed.userId}｜RSSI ${r.rssi}'
                      : '同 App（尚無身分）｜RSSI ${r.rssi}',
                ),
                trailing: parsed.userId >= 0
                    ? const Icon(Icons.arrow_forward_ios, size: 16)
                    : (isSel ? const Icon(Icons.check, color: Colors.green) : null),
                onTap: () {
                  setState(() => _selected = r.device);
                  _goExchangeIfPossible(r);
                },
              );
            },
          );
        },
      ),
      // 「完成」現在基本用不到（直接點項目就去交換頁），先保留
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () {
                    widget.onCancel?.call();
                    Navigator.of(context).maybePop();
                  },
                  child: const Text('取消'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton(
                  onPressed: _selected == null
                      ? null
                      : () {
                          // 舊流程：把被選中的 device 回傳（現行已改為直接 onTap 進交換頁）
                          Navigator.of(context).pop(_selected);
                        },
                  child: const Text('完成'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
