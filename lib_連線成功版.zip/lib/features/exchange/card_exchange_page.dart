// lib/features/exchange/card_exchange_page.dart
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../data/supabase_services.dart';
import '../../data/models/user_complete_profile.dart';


class CardExchangePage extends StatefulWidget {
  const CardExchangePage({
    super.key,
    required this.peerUserId,
    required this.sessionToken,
  });

  final int peerUserId;          // 對方 userId（掃描或 mfg 解析出來）
  final Uint8List sessionToken;  // 8 bytes 會期 token（暫時沒用到，可用於雙向互認）

  @override
  State<CardExchangePage> createState() => _CardExchangePageState();
}

class _CardExchangePageState extends State<CardExchangePage> {
  late final SupabaseService _svc;

  @override
  void initState() {
    super.initState();
    _svc = SupabaseService(Supabase.instance.client); // 走你現有的 factory
  }

  Future<UserCompleteProfile?> _load() {
    return _svc.fetchUserCompleteProfile(widget.peerUserId);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('交換名片｜對方 #${widget.peerUserId}')),
      body: FutureBuilder<UserCompleteProfile?>(
        future: _load(),
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          final profile = snap.data;
          if (profile == null) {
            return const Center(child: Text('讀取對方名片失敗或不存在'));
          }

          return Padding(
            padding: const EdgeInsets.all(16),
            child: ListView(
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CircleAvatar(
                      radius: 36,
                      backgroundImage: (profile.avatarUrl?.isNotEmpty ?? false)
                          ? NetworkImage(profile.avatarUrl!)
                          : null,
                      child: (profile.avatarUrl?.isEmpty ?? true)
                          ? const Icon(Icons.person, size: 36)
                          : null,
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(profile.username ?? '未填姓名',
                              style: Theme.of(context).textTheme.titleLarge),
                          const SizedBox(height: 4),
                          Text(
                            [
                              if ((profile.company ?? '').isNotEmpty) profile.company!,
                              if ((profile.jobTitle ?? '').isNotEmpty) profile.jobTitle!,
                            ].join('｜'),
                            style: Theme.of(context).textTheme.bodyMedium,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                if ((profile.skill ?? '').isNotEmpty)
                  ListTile(
                    leading: const Icon(Icons.star),
                    title: Text(profile.skill!),
                    subtitle: const Text('專長 / 技能'),
                  ),
                if ((profile.email ?? '').isNotEmpty)
                  ListTile(
                    leading: const Icon(Icons.email),
                    title: Text(profile.email!),
                  ),
                if ((profile.phone ?? '').isNotEmpty)
                  ListTile(
                    leading: const Icon(Icons.phone),
                    title: Text(profile.phone!),
                  ),
                const Divider(),
                // TODO: 如果你有 social links，就把它們顯示出來
                // 這裡先留個區塊，之後可透過 _svc.syncSocialLinks / 查詢表來補
                const SizedBox(height: 8),
                Text('本次交換 token：${widget.sessionToken.map((b) => b.toRadixString(16).padLeft(2, '0')).join()}',
                    style: Theme.of(context).textTheme.bodySmall),
                const SizedBox(height: 24),
                FilledButton.icon(
                  onPressed: () {
                    // 這邊之後可以打 API：把「我和對方」寫入 contact_relationships（accepted）
                    // 目前先當作成功，返回上一頁。
                    Navigator.of(context).pop(true);
                  },
                  icon: const Icon(Icons.person_add),
                  label: const Text('加入聯絡人'),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
